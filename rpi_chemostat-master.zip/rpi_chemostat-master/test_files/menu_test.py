import threading

# initialize global variables for threading
temp = 40.0
setpoint_T = 37.0
pH = 7.00
optical_density = 0.00
setpoint_OD = 2
duty_cycle = 0
heat = 'OFF'
run = True

# t7 = threading.Thread(target = menu,)
# t7.start()

def menu():
    global setpoint_T
    global setpoint_OD
    global duty_cycle
    global run
    
    while True:
        print ('Select the setpoint you would like to change.\n1: Temperature\n2: Sparging\n3: Optical Density\n4: End Chemostat Run')
        selection = int(input())
        if selection == 1:
            value = int(input('Enter the new temperature setpoint.\n'))
            setpoint_T = value
        if selection == 2:
            duty_cycle = int(input('Desired sparging percentage (0-100).\n'))
        
        if selection == 3:
            setpoint_OD = int(input('Enter the new optical density setpoint.\n'))
        
        if selection == 4:
            verify = input('Are you sure you want to end this run? Y/N\n')
            
            if verify == Y or verify == y:
                run = False
            else:
                run = True
menu()
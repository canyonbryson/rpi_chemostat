#  relay test

import time
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

key = 'go'
relay = 14

GPIO.setup(relay, GPIO.OUT)
GPIO.output(relay, True) # set relay to start off

try:
    while key != 'stop':
        #key = input("on/off: ")
        #print (key)
        #if key == 'on':
        print ('on')
        GPIO.output(relay, False)
        time.sleep(5)
        #if key == 'off':
        print ('off')
        GPIO.output(relay, True)
        time.sleep(5)
               
except KeyboardInterrupt:
        GPIO.cleanup()

GPIO.cleanup()
import busio
import time
import digitalio
import board
import adafruit_mcp3xxx.mcp3008 as MCP
from adafruit_mcp3xxx.analog_in import AnalogIn

# create the spi bus
spi = busio.SPI(clock=board.SCK, MISO=board.MISO, MOSI=board.MOSI)

# create the cs (chip select)
cs = digitalio.DigitalInOut(board.D13)

# create the mcp object
mcp = MCP.MCP3008(spi, cs)

# create an analog input channel on pin 0 and pin 1
chan1 = AnalogIn(mcp, MCP.P0)
chan2 = AnalogIn(mcp, MCP.P1)

'''
# test to see if things are working
for i in range (20):
    print('Light Raw ADC Value: ', chan1.value)
    print('Light ADC Voltage: ' + str(chan1.voltage) + 'V')
    print('pH Raw: ', chan2.value, 'Voltage: ', chan2.voltage)
    print('pH ADC Voltage: ' + str(chan2.voltage) + 'V')
    time.sleep(1)
'''

'''
# run 120 measurements at 1 second intervals for pH calibration
for i in range (120):
    ph = 0
    if i % 10 == 0:
        print (i)
    ph += (chan2.voltage)
    time.sleep(1)
    if i == 119:
        print ('Average voltage ph 10 : ', ph/120)
'''
'''
# test to see if pH readings are accurate
while True:
    raw = [0,0,0,0,0,0,0,0,0,0]
    summation = 0

    # read 10 values at 0.5 sec intervals
    for i in range (10):
        raw[i] = chan2.voltage
        time.sleep(0.2)
        
    # go through and order the readings from smallest to largest
    for i in range (10):
        for j in range (i+1, 10):
            if raw[i]>raw[j]: # go through and order the readings from smallest to largest
                temp = raw[i]
                raw[i] = raw[j]
                raw[i] = temp
                
    # average the middle six readings together
    for i in range (2,8):
        summation += raw[i]
    average = summation / 6

    pH = -8.8413 * average + 21.55 # use calibration equation to determine ph value
    print ('pH: ', round(pH,3))
    
    time.sleep(0.2)
'''

# test to see if we can plug in the voltage for calibration
while True:
    # values for calibration
    v4 = 1.9870127412832845 # format (x1,y1) = (voltage, pH)
    v10 = 1.3067801937895778 # format (x2,y2) = (voltage, pH)
    slope = (10-4)/(v10-v4) # (y2-y1/x2-x1)
    raw = [0,0,0,0,0,0,0,0,0,0]
    summation = 0

    # read 10 values at 0.5 sec intervals
    for i in range (10):
        raw[i] = chan2.voltage
        time.sleep(0.2)
        
    # go through and order the readings from smallest to largest
    for i in range (10):
        for j in range (i+1, 10):
            if raw[i]>raw[j]: # go through and order the readings from smallest to largest
                temp = raw[i]
                raw[i] = raw[j]
                raw[i] = temp
                
    # average the middle six readings together
    for i in range (2,8):
        summation += raw[i]
    average = summation / 6
    # y = y1 + m(x-x1)
    pH = 10 + slope*(average - v10)  # use point slope from calibration to determine ph value
    print ('pH: ', round(pH,3))
    
    time.sleep(0.2)

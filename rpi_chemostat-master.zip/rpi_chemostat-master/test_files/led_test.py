# led test

import time
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

led = 20
GPIO.setup(led, GPIO.OUT)
count = 0

try:
    while count < 5:
        #print ("ON")
        GPIO.output(led , True)
        time.sleep(0.5)
        #print ("OFF")
        GPIO.output(led , False)
        time.sleep(0.5)
        count += 1
except KeyboardInterrupt:
    GPIO.cleanup()

GPIO.cleanup()
# motor test

import time
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)


en1 = 18 # media pump enable
en2 = 12 # air pump enable
m_in = 25 # media in 
m_out = 24 # media out
m_air = 23 # air pump
count = 0
sleep = 10 # for time.sleep()
dc = 100 # duty cycle for air
frequency = 1000

GPIO.setup(en1, GPIO.OUT)
GPIO.setup(en2, GPIO.OUT)
GPIO.setup(m_in, GPIO.OUT)
GPIO.setup(m_out, GPIO.OUT)
GPIO.setup(m_air, GPIO.OUT)

speedair = GPIO.PWM(en2, frequency)
speedair.start(dc)

GPIO.output(en2 , True)
GPIO.output(m_air , True)

try:
    while True:
        key = int(input("Air Speed?: "))
        #print (key)
        speedair.ChangeDutyCycle(key)
               
except KeyboardInterrupt:
        GPIO.cleanup()

GPIO.cleanup()
    
    
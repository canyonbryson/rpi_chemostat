from datetime import datetime


now = datetime.now()
print (now)
date = now.strftime("%m-%d-%y_%H:%M:%S")
print (date)
pH = 5
temp = 6
optical_density = 5


file = open('{}.csv'.format(date),'w+')
file.write('Chemostat run of {}'.format(date))
file.write('\nTimestamp, Temperature, pH, OD,\n')
file.write('{0},{1},{2},{3},'.format(date,temp,pH,optical_density))
file.close()